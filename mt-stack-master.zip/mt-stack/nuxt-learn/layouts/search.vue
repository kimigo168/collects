<template>
  <div class="layout-search">
    <h1>search layout header</h1>
    <nuxt/>
    <footer>search layout footer</footer>
  </div>
</template>

<script>
export default {
}
</script>

<style lang="css">
  .layout-search{
    color:red;
  }
</style>
