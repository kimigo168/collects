<template>
  <div class="layout-blank">
    <nuxt/>
  </div>
</template>

<script>
export default {
}
</script>

<style lang="css">
</style>
