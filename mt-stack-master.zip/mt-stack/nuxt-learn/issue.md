## 问题及解决方案

<dl>
    <dt>
        问题1：in ./server/index.js**
        Module build failed: Error: Plugin/Preset files are not allowed to export objects, only functions. In /Users/ygh/stack/source/chapter-5/node_modules/backpack-core/babel.js
    </dt>
    <dd>
        解决方案：npm install nuxt@1.4.2 最新版本会有问题，降级到1.4.2**
    </dd>
</dl>
