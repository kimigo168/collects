<template lang="html">
  <div class="page">
    page a
  </div>
</template>

<script>
export default {
}
</script>

<style lang="css">
</style>
